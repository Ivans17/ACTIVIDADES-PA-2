using System;
using System.Text;
using System.Security.Cryptography;

public static class Seguridad
{
    private static readonly string clave = "clave12345678901";

    public static string Encriptar(string texto)
    {
        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(clave);
            aes.IV = new byte[16];

            ICryptoTransform encryptor = aes.CreateEncryptor();
            byte[] inputBytes = Encoding.UTF8.GetBytes(texto);
            byte[] encrypted = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
            return Convert.ToBase64String(encrypted);
        }
    }

    public static string Desencriptar(string textoEncriptado)
    {
        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(clave);
            aes.IV = new byte[16];

            ICryptoTransform decryptor = aes.CreateDecryptor();
            byte[] inputBytes = Convert.FromBase64String(textoEncriptado);
            byte[] decrypted = decryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
            return Encoding.UTF8.GetString(decrypted);
        }
    }
}