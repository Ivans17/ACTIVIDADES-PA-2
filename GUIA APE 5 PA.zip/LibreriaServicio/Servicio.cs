public class Servicio : IServicio
{
    public string EnviarMensaje(string mensajeEncriptado)
    {
        string mensaje = Seguridad.Desencriptar(mensajeEncriptado);
        string respuesta = "Mensaje recibido: " + mensaje;
        return Seguridad.Encriptar(respuesta);
    }
}