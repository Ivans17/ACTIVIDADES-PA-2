using System.ServiceModel;

[ServiceContract]
public interface IServicio
{
    [OperationContract]
    string EnviarMensaje(string mensajeEncriptado);
}