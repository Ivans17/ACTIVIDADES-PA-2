using System;
using System.ServiceModel;
using System.Windows.Forms;
using LibreriaServicio;

namespace ClienteApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            NetTcpBinding binding = new NetTcpBinding(SecurityMode.None);
            ChannelFactory<IServicio> factory = new ChannelFactory<IServicio>(
                binding,
                new EndpointAddress("net.tcp://localhost:9001/Servicio")
            );

            IServicio proxy = factory.CreateChannel();

            string mensaje = txtMensaje.Text;
            string mensajeEncriptado = Seguridad.Encriptar(mensaje);
            string respuestaEncriptada = proxy.EnviarMensaje(mensajeEncriptado);
            string respuesta = Seguridad.Desencriptar(respuestaEncriptada);

            MessageBox.Show("Respuesta: " + respuesta);
        }
    }
}