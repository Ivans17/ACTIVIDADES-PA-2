using System;
using System.ServiceModel;
using System.Windows.Forms;
using LibreriaServicio;

namespace ServidorApp
{
    public partial class Form1 : Form
    {
        private ServiceHost host;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            host = new ServiceHost(typeof(Servicio));
            NetTcpBinding binding = new NetTcpBinding(SecurityMode.None);
            host.AddServiceEndpoint(typeof(IServicio), binding, "net.tcp://localhost:9001/Servicio");

            try
            {
                host.Open();
                MessageBox.Show("Servicio iniciado correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al iniciar servicio: " + ex.Message);
            }
        }
    }
}