﻿namespace NOTAS_APE.DTos
{
    public class PromedioDTO

    {

        public string Cedula { get; set; }

        public string Nombre { get; set; }

        public string Apellido { get; set; }

        public string Asignatura { get; set; }

        public decimal Promedio { get; set; }

        public string Estado { get; set; }

    }
}
