﻿namespace NOTAS_APE.DTos
{
    public class NotaUpdateDTO 

    { 

        public decimal Nota { get; set; } 

    } 
}
