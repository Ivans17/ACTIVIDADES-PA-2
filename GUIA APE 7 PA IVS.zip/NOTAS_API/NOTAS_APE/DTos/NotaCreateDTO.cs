﻿namespace NOTAS_APE.DTos
{
    public class NotaCreateDTO

    {

        public string Cedula_Es { get; set; }

        public int Curso_Id { get; set; }

        public decimal Nota { get; set; }

    }
}
