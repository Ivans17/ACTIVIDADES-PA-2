﻿using Microsoft.EntityFrameworkCore;
using NOTAS_APE.Data;
using NOTAS_APE.Repositories;
using NOTAS_APE.Services;

var builder = WebApplication.CreateBuilder(args);

// 🔗 Conexión a base de datos
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 🌍 Configurar CORS para permitir llamadas desde el frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("FrontendDev", policy =>
    {
        policy.WithOrigins("http://localhost:5249", "https://localhost:5249", "https://localhost:7175")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// 🧩 Repositorios
builder.Services.AddScoped<IEstudianteRepository, EstudianteRepository>();
builder.Services.AddScoped<INotaRepository, NotaRepository>();
builder.Services.AddScoped<IPromedioRepository, PromedioRepository>();

// 🧠 Servicios
builder.Services.AddScoped<EstudianteService>();
builder.Services.AddScoped<NotaService>();
builder.Services.AddScoped<PromedioService>();

// 🔧 Configuración MVC + Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 🌐 Swagger solo en desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 📁 Archivos estáticos (frontend en wwwroot)
app.UseDefaultFiles();
app.UseStaticFiles();

// 🧱 Usar CORS
app.UseCors("FrontendDev");

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

app.Run();
