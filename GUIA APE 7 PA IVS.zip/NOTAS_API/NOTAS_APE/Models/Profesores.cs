﻿namespace NOTAS_APE.Models
{
    public class Profesores

    {

        public string Cedula { get; set; }

        public string Nombre { get; set; }

        public string Apellido { get; set; }

        public string Materia { get; set; }

        public string Correo { get; set; }

    }
}
